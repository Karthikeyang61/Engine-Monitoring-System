gyro.o: ../gyro.c ../gyroheader.h
../gyroheader.h:
