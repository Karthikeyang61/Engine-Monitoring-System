main.o: ../main.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_kernel.h \
 ../app.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_kernel.h:
../app.h:
