simplicity_sdk_2025.6.2/platform/service/mem_pool/src/sl_mem_pool.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/mem_pool/src/sl_mem_pool.c \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_core.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_code_classification.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\mem_pool\inc\sli_mem_pool.h
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_core.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_code_classification.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\mem_pool\inc\sli_mem_pool.h:
