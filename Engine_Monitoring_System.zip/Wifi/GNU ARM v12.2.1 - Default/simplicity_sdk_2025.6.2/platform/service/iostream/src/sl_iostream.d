simplicity_sdk_2025.6.2/platform/service/iostream/src/sl_iostream.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/iostream/src/sl_iostream.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sli_iostream.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_core.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_code_classification.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_cmsis_os2_ext_task_register.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\freertos.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/FreeRTOSConfig.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\projdefs.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\portable.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\deprecated_definitions.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\portable\gcc\arm_cm4f\portmacro.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\mpu_wrappers.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\task.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\list.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sli_iostream.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_core.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_code_classification.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sli_cmsis_os2_ext_task_register.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\freertos.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/FreeRTOSConfig.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\projdefs.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\portable.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\deprecated_definitions.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\portable\gcc\arm_cm4f\portmacro.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\mpu_wrappers.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_code_classification.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\task.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\util\third_party\freertos\kernel\include\list.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
