simplicity_sdk_2025.6.2/platform/service/sl_main/src/sl_main_init_memory.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/sl_main/src/sl_main_init_memory.c \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/sl_main/src/sli_main_init_memory.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init_memory.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_event_handler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h
C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/sl_main/src/sli_main_init_memory.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init_memory.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_event_handler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
