simplicity_sdk_2025.6.2/platform/service/sl_main/src/rtos/main_retarget.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/service/sl_main/src/rtos/main_retarget.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_kernel.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init_memory.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_kernel.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\sl_main\inc\sl_main_init_memory.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
