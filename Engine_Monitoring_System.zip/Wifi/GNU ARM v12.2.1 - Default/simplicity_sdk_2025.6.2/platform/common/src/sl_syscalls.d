simplicity_sdk_2025.6.2/platform/common/src/sl_syscalls.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/common/src/sl_syscalls.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_compiler.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_compiler.h:
