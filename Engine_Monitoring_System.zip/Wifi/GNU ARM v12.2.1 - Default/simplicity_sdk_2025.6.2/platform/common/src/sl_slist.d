simplicity_sdk_2025.6.2/platform/common/src/sl_slist.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/platform/common/src/sl_slist.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
