autogen/sl_event_handler.o: ../autogen/sl_event_handler.c \
 ../autogen/sl_event_handler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_nvic_priorities_config.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/FreeRTOSConfig.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\service\clock_manager\inc\sl_si91x_clock_manager.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/RTE_Device_917.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/pin_config.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\sli_siwx917_soc.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\board\silabs\inc\rsi_board.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\common\inc\rsi_debug.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h \
 ../autogen/sl_si91x_button_instances.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\hardware_drivers\button\inc\sl_si91x_button.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_peripheral_gpio.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_gpio.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_gpio_common.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/sl_si91x_button_init_btn0_config.h \
 ../autogen/sl_iostream_init_instances.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h \
 ../autogen/sl_iostream_handles.h
../autogen/sl_event_handler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_nvic_priorities_config.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/FreeRTOSConfig.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\service\clock_manager\inc\sl_si91x_clock_manager.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/RTE_Device_917.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/pin_config.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\sli_siwx917_soc.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\board\silabs\inc\rsi_board.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\common\inc\rsi_debug.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
../autogen/sl_si91x_button_instances.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\hardware_drivers\button\inc\sl_si91x_button.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_peripheral_gpio.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_gpio.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\unified_peripheral_drivers\inc\sl_si91x_gpio_common.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/sl_si91x_button_init_btn0_config.h:
../autogen/sl_iostream_init_instances.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
../autogen/sl_iostream_handles.h:
