autogen/sl_iostream_handles.o: ../autogen/sl_iostream_handles.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 ../autogen/sl_iostream_handles.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\service\iostream\inc\sl_iostream.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_enum.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
../autogen/sl_iostream_handles.h:
