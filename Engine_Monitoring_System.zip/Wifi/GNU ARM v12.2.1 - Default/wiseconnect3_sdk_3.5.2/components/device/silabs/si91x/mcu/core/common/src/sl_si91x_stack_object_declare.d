wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/common/src/sl_si91x_stack_object_declare.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/components/device/silabs/si91x/mcu/core/common/src/sl_si91x_stack_object_declare.c \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/sl_si91x_stack_size_config.h
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/sl_si91x_stack_size_config.h:
