wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/common/src/rsi_debug.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/components/device/silabs/si91x/mcu/core/common/src/rsi_debug.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\common\inc\rsi_debug.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\usart.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/RTE_Device_917.h \
 C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/pin_config.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ulpss_clk.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ulpss_clk.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_power_save.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_system_config.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\cmsis\driver\include\driver_usart.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\cmsis\driver\include\Driver_Common.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\UDMA.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\Driver_Common.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\peripheral_drivers\inc\rsi_udma.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\rom_driver\inc\rsi_packing.h \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\common\inc\rsi_debug.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\autogen/sl_component_catalog.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\usart.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/RTE_Device_917.h:
C:\Users\karth\SimplicityStudio\v5_workspace\Wifi\config/pin_config.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ulpss_clk.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_pll.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ulpss_clk.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_power_save.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_system_config.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\cmsis\driver\include\driver_usart.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\cmsis\driver\include\Driver_Common.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\UDMA.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\cmsis_driver\Driver_Common.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\peripheral_drivers\inc\rsi_udma.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\rom_driver\inc\rsi_packing.h:
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
