wiseconnect3_sdk_3.5.2/third_party/json_parser/src/jsmn.o: \
 C:/Users/karth/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/third_party/json_parser/src/jsmn.c \
 c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\third_party\json_parser\include\jsmn.h
c:\users\karth\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\third_party\json_parser\include\jsmn.h:
