#include "imu_driver.h"
#include "sl_si91x_i2c.h"
#include <stdint.h>

#define IMU_ADDR 0x68

#define REG_PWR_MGMT0 0x4E
#define REG_ACCEL_XOUT_H 0x1F
#define REG_GYRO_XOUT_H  0x25
#define REG_TEMP_OUT_H   0x1D

static I2C_TypeDef *i2c = I2C0;

/* write register */

static void imu_write(uint8_t reg, uint8_t val)
{
  sl_si91x_i2c_start_cmd(i2c);

  sl_si91x_i2c_tx(i2c, (IMU_ADDR << 1));
  sl_si91x_i2c_tx(i2c, reg);
  sl_si91x_i2c_tx(i2c, val);

  sl_si91x_i2c_stop_cmd(i2c);
}

/* read registers */

static void imu_read(uint8_t reg, uint8_t *data, uint8_t len)
{
  sl_si91x_i2c_start_cmd(i2c);

  sl_si91x_i2c_tx(i2c, (IMU_ADDR << 1));
  sl_si91x_i2c_tx(i2c, reg);

  sl_si91x_i2c_start_cmd(i2c);

  sl_si91x_i2c_tx(i2c, (IMU_ADDR << 1) | 1);

  for(int i=0;i<len;i++)
    data[i] = sl_si91x_i2c_rx(i2c);

  sl_si91x_i2c_stop_cmd(i2c);
}

/* init sensor */

void imu_init()
{
  sl_i2c_init_params_t config = {0};

  config.mode = SL_I2C_MASTER;
  config.freq = 400000;

  sl_si91x_i2c_init(i2c,&config);

  /* enable accel + gyro */

  imu_write(REG_PWR_MGMT0,0x0F);
}

/* read accel */

void imu_get_accel(float *accel)
{
  uint8_t buf[6];

  imu_read(REG_ACCEL_XOUT_H,buf,6);

  int16_t ax = (buf[0]<<8)|buf[1];
  int16_t ay = (buf[2]<<8)|buf[3];
  int16_t az = (buf[4]<<8)|buf[5];

  accel[0] = ax/2048.0;
  accel[1] = ay/2048.0;
  accel[2] = az/2048.0;
}

/* read gyro */

void imu_get_gyro(float *gyro)
{
  uint8_t buf[6];

  imu_read(REG_GYRO_XOUT_H,buf,6);

  int16_t gx = (buf[0]<<8)|buf[1];
  int16_t gy = (buf[2]<<8)|buf[3];
  int16_t gz = (buf[4]<<8)|buf[5];

  gyro[0] = gx/16.4;
  gyro[1] = gy/16.4;
  gyro[2] = gz/16.4;
}

/* read temperature */

void imu_get_temperature(float *temp)
{
  uint8_t buf[2];

  imu_read(REG_TEMP_OUT_H,buf,2);

  int16_t raw = (buf[0]<<8)|buf[1];

  *temp = (raw/132.48)+25;
}
