#include "gyroheader.h"
#include <stdio.h>

/* simulated sensor values */

static float ax = 0;
static float ay = 0;
static float az = 9.8;

static float gx = 0;
static float gy = 0;
static float gz = 0;

static float temperature = 28.0;

void icm40627_example_init(void)
{
  printf("ICM40627 initialized\n");
}

void icm40627_example_get_accel(float accel[3])
{
  ax += 0.02;
  ay += 0.01;

  accel[0] = ax;
  accel[1] = ay;
  accel[2] = az;
}

void icm40627_example_get_gyro(float gyro[3])
{
  gx += 0.5;
  gy += 0.3;
  gz += 0.2;

  gyro[0] = gx;
  gyro[1] = gy;
  gyro[2] = gz;
}

void icm40627_example_get_temperature(float *temp)
{
  temperature += 0.01;

  *temp = temperature;
}
