#ifndef DASHBOARD_HTML_H
#define DASHBOARD_HTML_H

static const char html_page[] =
"<!DOCTYPE html>"
"<html>"
"<head>"

"<meta name='viewport' content='width=device-width, initial-scale=1'>"

"<title>SI917 IMU Dashboard</title>"

"<style>"

"body{"
"margin:0;"
"font-family:Arial,Helvetica,sans-serif;"
"background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);"
"color:white;"
"text-align:center;"
"}"

"h1{"
"margin-top:30px;"
"font-size:36px;"
"letter-spacing:2px;"
"}"

".container{"
"display:flex;"
"flex-wrap:wrap;"
"justify-content:center;"
"gap:20px;"
"margin-top:40px;"
"}"

".card{"
"background:rgba(255,255,255,0.1);"
"backdrop-filter:blur(10px);"
"border-radius:15px;"
"padding:25px;"
"width:250px;"
"box-shadow:0 10px 25px rgba(0,0,0,0.3);"
"}"

".card h2{"
"margin-bottom:15px;"
"font-size:22px;"
"}"

".value{"
"font-size:28px;"
"font-weight:bold;"
"margin:5px;"
"}"

".label{"
"font-size:14px;"
"color:#ddd;"
"}"

".footer{"
"margin-top:40px;"
"font-size:14px;"
"color:#bbb;"
"}"

"</style>"

"<script>"

"async function update(){"
"try{"

"let r = await fetch('/sensor?'+Date.now());"
"let j = await r.json();"

"document.getElementById('ax').innerText=j.ax.toFixed(2);"
"document.getElementById('ay').innerText=j.ay.toFixed(2);"
"document.getElementById('az').innerText=j.az.toFixed(2);"

"document.getElementById('gx').innerText=j.gx.toFixed(2);"
"document.getElementById('gy').innerText=j.gy.toFixed(2);"
"document.getElementById('gz').innerText=j.gz.toFixed(2);"

"document.getElementById('temp').innerText=j.t.toFixed(2);"

"}catch(e){"
"console.log('Sensor update failed');"
"}"
"}"

/* Run immediately when page loads */
"window.onload=function(){"
"update();"
"setInterval(update,500);"
"};"

"</script>"

"</head>"

"<body>"

"<h1>SI917 IMU Dashboard</h1>"

"<div class='container'>"

"<div class='card'>"
"<h2>Accelerometer</h2>"
"<div class='label'>X Axis</div>"
"<div class='value' id='ax'>0</div>"
"<div class='label'>Y Axis</div>"
"<div class='value' id='ay'>0</div>"
"<div class='label'>Z Axis</div>"
"<div class='value' id='az'>0</div>"
"</div>"

"<div class='card'>"
"<h2>Gyroscope</h2>"
"<div class='label'>X Axis</div>"
"<div class='value' id='gx'>0</div>"
"<div class='label'>Y Axis</div>"
"<div class='value' id='gy'>0</div>"
"<div class='label'>Z Axis</div>"
"<div class='value' id='gz'>0</div>"
"</div>"

"<div class='card'>"
"<h2>Temperature</h2>"
"<div class='value' id='temp'>0</div>"
"<div class='label'>°C</div>"
"</div>"

"</div>"

"<div class='footer'>"
"Real-time Sensor Monitoring | SI917 Embedded Web Server"
"</div>"

"</body>"
"</html>";

#endif
