#ifndef GYROHEADER_H
#define GYROHEADER_H

#include <stdint.h>

void icm40627_example_init(void);

void icm40627_example_get_accel(float accel[3]);

void icm40627_example_get_gyro(float gyro[3]);

void icm40627_example_get_temperature(float *temp);

#endif
