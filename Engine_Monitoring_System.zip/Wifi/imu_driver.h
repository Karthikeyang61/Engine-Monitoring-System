#ifndef IMU_DRIVER_H
#define IMU_DRIVER_H

#include <stdint.h>

void imu_init();

void imu_get_accel(float *accel);
void imu_get_gyro(float *gyro);
void imu_get_temperature(float *temp);

#endif
