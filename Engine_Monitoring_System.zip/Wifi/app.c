#include <stdio.h>
#include <string.h>

#include "app.h"
#include "sl_net.h"
#include "sl_wifi.h"
#include "sl_http_server.h"
#include "sl_net_wifi_types.h"
#include "sl_si91x_socket.h"
#include "sl_net_si91x.h"

#include "gyroheader.h"
#include "imu_driver.h"

/* WIFI CONFIG */

#define WIFI_SSID "Galaxy A31"
#define WIFI_PASS "sollanuma"

/* GLOBALS */

static sl_http_server_t server_handle;

float accel[3];
float gyro[3];
float temp;

/* ================= HTML DASHBOARD ================= */

static const char html_page[] =
"<!DOCTYPE html>"
"<html>"
"<head>"
"<meta name='viewport' content='width=device-width, initial-scale=1'>"
"<title>SI917 IMU Dashboard</title>"

"<style>"
"body{margin:0;font-family:Arial;background:#111;color:white;text-align:center;}"
"h1{margin-top:30px}"
".container{display:flex;flex-wrap:wrap;justify-content:center;margin-top:40px}"
".card{background:#1e1e1e;border-radius:10px;padding:20px;margin:10px;width:220px}"
".value{font-size:28px;font-weight:bold}"
"</style>"

"<script>"
"async function update(){"
"let r = await fetch('/sensor?'+Date.now());"
"let j = await r.json();"

"document.getElementById('ax').innerText=j.ax.toFixed(2);"
"document.getElementById('ay').innerText=j.ay.toFixed(2);"
"document.getElementById('az').innerText=j.az.toFixed(2);"

"document.getElementById('gx').innerText=j.gx.toFixed(2);"
"document.getElementById('gy').innerText=j.gy.toFixed(2);"
"document.getElementById('gz').innerText=j.gz.toFixed(2);"

"document.getElementById('temp').innerText=j.t.toFixed(2);"
"}"

"window.onload=function(){"
"update();"
"setInterval(update,500);"
"}"
"</script>"
"</head>"

"<body>"

"<h1>SI917 IMU Dashboard</h1>"

"<div class='container'>"

"<div class='card'>"
"<h2>Accelerometer</h2>"
"X:<div class='value' id='ax'>0</div>"
"Y:<div class='value' id='ay'>0</div>"
"Z:<div class='value' id='az'>0</div>"
"</div>"

"<div class='card'>"
"<h2>Gyroscope</h2>"
"X:<div class='value' id='gx'>0</div>"
"Y:<div class='value' id='gy'>0</div>"
"Z:<div class='value' id='gz'>0</div>"
"</div>"

"<div class='card'>"
"<h2>Temperature</h2>"
"<div class='value' id='temp'>0</div>"
"</div>"

"</div>"
"</body>"
"</html>";

/* ================= DASHBOARD PAGE ================= */

static sl_status_t dashboard_handler(sl_http_server_t *handle,
                                     sl_http_server_request_t *req)
{
  (void)req;

  sl_http_server_response_t response;

  response.response_code = SL_HTTP_RESPONSE_OK;
  response.content_type = SL_HTTP_CONTENT_TYPE_TEXT_HTML;
  response.data = (uint8_t*)html_page;
  response.current_data_length = strlen(html_page);
  response.expected_data_length = strlen(html_page);
  response.headers = NULL;
  response.header_count = 0;

  return sl_http_server_send_response(handle,&response);
}

/* ================= SENSOR JSON API ================= */

static sl_status_t sensor_handler(sl_http_server_t *handle,
                                  sl_http_server_request_t *req)
{
  (void)req;

  /* READ REAL SENSOR */

  imu_get_accel(accel);
  imu_get_gyro(gyro);
  imu_get_temp(&temp);

  char json[256];

  snprintf(json,sizeof(json),
  "{"
  "\"ax\":%.2f,"
  "\"ay\":%.2f,"
  "\"az\":%.2f,"
  "\"gx\":%.2f,"
  "\"gy\":%.2f,"
  "\"gz\":%.2f,"
  "\"t\":%.2f"
  "}",
  accel[0],accel[1],accel[2],
  gyro[0],gyro[1],gyro[2],
  temp);

  sl_http_server_response_t response;

  response.response_code = SL_HTTP_RESPONSE_OK;
  response.content_type = SL_HTTP_CONTENT_TYPE_APPLICATION_JSON;
  response.data = (uint8_t*)json;
  response.current_data_length = strlen(json);
  response.expected_data_length = strlen(json);
  response.headers = NULL;
  response.header_count = 0;

  return sl_http_server_send_response(handle,&response);
}

/* ================= ROUTES ================= */

static sl_http_server_handler_t handlers[] =
{
 { .uri="/", .handler=dashboard_handler },
 { .uri="/sensor", .handler=sensor_handler }
};

/* ================= APP INIT ================= */

void app_init(void)
{
  printf("Starting WiFi...\n");

  sl_net_init(SL_NET_WIFI_CLIENT_INTERFACE,
              &sl_wifi_default_client_configuration,
              NULL,
              NULL);

  sl_net_set_credential(
        SL_NET_DEFAULT_WIFI_CLIENT_CREDENTIAL_ID,
        SL_NET_WIFI_PSK,
        WIFI_PASS,
        strlen(WIFI_PASS));

  sl_wifi_client_configuration_t ap={0};

  ap.ssid.length = strlen(WIFI_SSID);
  memcpy(ap.ssid.value,WIFI_SSID,ap.ssid.length);

  ap.security = SL_WIFI_WPA2;
  ap.encryption = SL_WIFI_CCMP_ENCRYPTION;
  ap.credential_id = SL_NET_DEFAULT_WIFI_CLIENT_CREDENTIAL_ID;

  printf("Connecting to WiFi...\n");

  sl_wifi_connect(SL_WIFI_CLIENT_2_4GHZ_INTERFACE,&ap,10000);

  printf("WiFi connected\n");

  sl_net_wifi_client_profile_t profile;

  sl_net_get_profile(SL_NET_WIFI_CLIENT_INTERFACE,
                     SL_NET_PROFILE_ID_0,
                     (sl_net_profile_t*)&profile);

  sl_si91x_configure_ip_address(&profile.ip,
                                SL_SI91X_WIFI_CLIENT_VAP_ID);

  printf("Board IP: %d.%d.%d.%d\n",
  profile.ip.ip.v4.ip_address.bytes[0],
  profile.ip.ip.v4.ip_address.bytes[1],
  profile.ip.ip.v4.ip_address.bytes[2],
  profile.ip.ip.v4.ip_address.bytes[3]);

  /* INIT IMU SENSOR */

  printf("Initializing IMU...\n");

  imu_init();

  printf("Sensor ready\n");

  /* HTTP SERVER */

  sl_http_server_config_t config={0};

  config.port = 80;
  config.handlers_list = handlers;
  config.handlers_count =
      sizeof(handlers)/sizeof(sl_http_server_handler_t);

  sl_http_server_init(&server_handle,&config);
  sl_http_server_start(&server_handle);

  printf("HTTP Server started\n");
}

/* ================= LOOP ================= */

void app_process_action(void)
{
}
